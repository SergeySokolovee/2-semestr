def umn_list(numbers):
    result = 1
    for num in numbers:
        result *= num
    return result if numbers else 0

print(umn_list([1, 2, 3, 4, 5]))