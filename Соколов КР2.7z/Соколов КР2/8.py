def diap(n, start, end):
    return start <= n <= end

print(diap(5, 1, 10))