def three_args(*, var1=None, var2=None, var3=None):
    args = {k: v for k, v in {"var1": var1, "var2": var2, "var3": var3}.items() if v is not None}

    if args:
        print("Переданы аргументы:", ", ".join(f"{k} = {v}" for k, v in args.items()))
    else:
        print("Аргументы не найдены")

three_args(var1=2, var3=10)