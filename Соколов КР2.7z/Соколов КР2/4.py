def sum_list(numbers):
    return sum(numbers)

print(sum_list([1, 2, 3, 4, 5]))