def max_three(a, b ,c):
    return max(a, b, c)

print(max_three(1, 5, 8))