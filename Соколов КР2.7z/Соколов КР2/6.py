def reverse(s):
    return s[::-1]

print(reverse("hello"))